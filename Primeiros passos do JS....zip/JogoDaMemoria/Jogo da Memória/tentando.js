const cartas = document.querySelectorAll('.memory-card');
var cont = 0;
var primeiraCarta, segundaCarta;

function carregarJogo() {
    cartas.forEach(carta => {
        let jogoEmbaralhado = Math.floor(Math.random() * 12);
        carta.style.order = jogoEmbaralhado;
    });
}

function virarCarta() {
    if (cont < 3) {
        this.classList.add('virar');
        cont++;
        if (cont == 1) {
            primeiraCarta = this;
        }
        if (cont == 2) {
            segundaCarta = this;
            verificarMatch();
        }
    }
}

function verificarMatch() {
    if (primeiraCarta.dataset.framework === segundaCarta.dataset.framework) {

    } else {
        setTimeout(() => {
            primeiraCarta.classList.remove('virar');
            segundaCarta.classList.remove('virar');
            cont = 0;
        }, 1300);
    }
}

carregarJogo();
cartas.forEach(carta => carta.addEventListener('click', virarCarta));



